﻿using UnityEngine;
using System.Collections;

public class GameoverWindow : GenericWindow {

	public void OnNext(){
		manager.Open (0);
	}
}

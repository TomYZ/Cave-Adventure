﻿using UnityEngine;
using System.Collections;

public class InGameWindow : GenericWindow {

	public void GameOver(){
		manager.Open (2);
	}
}
